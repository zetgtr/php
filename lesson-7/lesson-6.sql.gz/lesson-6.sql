-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Апр 17 2022 г., 14:24
-- Версия сервера: 8.0.24
-- Версия PHP: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `lesson-6`
--

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id` int NOT NULL,
  `name` varchar(20) NOT NULL,
  `size` int NOT NULL,
  `count` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `name`, `size`, `count`) VALUES
(2, 'photo1.jpg', 46004, 3),
(3, 'photo2.jpg', 42646, 1),
(4, 'photo3.jpg', 45964, 1),
(5, 'photo4.jpg', 655081, 15),
(6, 'photo5.jpg', 565825, 1),
(7, 'photo6.jpg', 903263, 1),
(8, 'photo7.jpg', 680039, 25),
(9, 'photo8.jpg', 1102534, 1),
(10, 'photo9.jpg', 696170, 3),
(11, 'photo10.jpg', 731830, 4),
(12, 'photo11.jpg', 602441, 1),
(13, 'photo12.jpg', 415050, 2),
(14, 'photo13.jpg', 593249, 1),
(15, 'photo14.jpg', 247994, 1),
(16, 'photo15.jpg', 162924, 2),
(17, 'photo16.jpg', 443784, 24),
(18, 'photo17.jpg', 164895, 1),
(19, 'photo18.jpg', 573219, 1),
(20, 'photo19.jpg', 331127, 1),
(21, 'photo20.jpg', 449795, 1),
(22, 'photo21.jpg', 509987, 1),
(23, 'photo22.jpg', 313115, 4),
(24, 'photo23.jpg', 439557, 1),
(25, 'photo24.jpg', 481725, 1),
(26, 'photo25.jpg', 925998, 1),
(27, 'photo26.jpg', 287860, 1),
(28, 'photo27.jpg', 536543, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `reviews`
--

CREATE TABLE `reviews` (
  `id` int NOT NULL,
  `name` varchar(20) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id_user` int NOT NULL,
  `login` varchar(10) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `admin` int DEFAULT '0',
  `session` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id_user`, `login`, `pass`, `admin`, `session`) VALUES
(7, 'admin', 'd41d8cd98f00b204e9800998ecf8427e', 1, '1osclq52l0b5v6tdus69risbdme246vf');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;

--
-- AUTO_INCREMENT для таблицы `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
